#!/usr/bin/env bash

prompt_setter() {
  # Save history
  history -a
  history -c
  history -r

  # if [ "$(whoami)" = root ]; then no_color=$red; else no_color=$blue; fi

  # FULL:
  # PS1="(\t) $(scm_char) [$blue\u$reset_color] $yellow\W${reset_color}$(scm_prompt_info)$(ruby_version_prompt)$reset_color $ "
  
  # DEFAULT:
  PS1="(\t) [$blue\u$reset_color] $yellow\W${reset_color}$(scm_prompt_info)$reset_color $ "

  # NO OPTIONS:
  # PS1="(\t) [$blue\u$reset_color] $yellow\W${reset_color}$reset_color $ "

  PS2='> '
  PS4='+ '
}

# PS1="(\t) $(scm_char) [$blue\u$reset_color] $yellow\W${reset_color}$(scm_prompt_info)$(ruby_version_prompt)$reset_color $ "
# Original prompt: 
# (\t): time
# $(scm_char): returns '±' for git, '☿' for hg, '⑆' for svn, and '○' for none.
# \u: current user
# \W: current directory
# $(scm_prompt_info): see below. Note that this slows down the prompt significantly.

PROMPT_COMMAND=prompt_setter

SCM_THEME_PROMPT_DIRTY=" ✗"
SCM_THEME_PROMPT_CLEAN=" ✓"
SCM_THEME_PROMPT_PREFIX=" ("
SCM_THEME_PROMPT_SUFFIX=")"
RVM_THEME_PROMPT_PREFIX=" ("
RVM_THEME_PROMPT_SUFFIX=")"
